package typedeclimport

import "testing"

func Test(t *testing.T) {
	// No need to do anything, if this test runs, it means it works
}
